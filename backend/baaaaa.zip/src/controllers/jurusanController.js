const Joi = require('joi');
const prisma = require('../config/prisma');

const jurusanSchema = Joi.object({
  kodeProdi: Joi.string().trim().min(1).max(20).required().messages({
    'string.empty': 'Kode Prodi tidak boleh kosong',
    'string.min': 'Kode Prodi minimal 1 karakter',
    'string.max': 'Kode Prodi maksimal 20 karakter',
    'any.required': 'Kode Prodi wajib diisi'
  }),
  namaProdi: Joi.string().trim().min(2).max(100).required().messages({
    'string.empty': 'Nama Prodi tidak boleh kosong',
    'any.required': 'Nama Prodi wajib diisi'
  }),
});

function isPrismaUniqueError(err) {
  return err && err.code === 'P2002';
}

exports.list = async (req, res) => {
  const items = await prisma.jurusan.findMany({
    orderBy: { namaProdi: 'asc' },
  });

  return res.json({
    success: true,
    data: items,
  });
};

exports.getById = async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ success: false, message: 'Invalid id' });
  }

  const item = await prisma.jurusan.findUnique({ where: { id } });
  if (!item) {
    return res.status(404).json({ success: false, message: 'Jurusan not found' });
  }

  return res.json({ success: true, data: item });
};

exports.create = async (req, res) => {
  const { error, value } = jurusanSchema.validate(req.body, { abortEarly: true });
  if (error) {
    return res.status(400).json({ success: false, message: error.details[0].message });
  }

  try {
    const created = await prisma.jurusan.create({
      data: { 
        kodeProdi: value.kodeProdi.trim(),
        namaProdi: value.namaProdi.trim() 
      },
    });

    return res.status(201).json({
      success: true,
      message: 'Jurusan created',
      data: created,
    });
  } catch (err) {
    if (isPrismaUniqueError(err)) {
      const field = err.meta?.target?.[0];
      if (field === 'kode_prodi') {
        return res.status(409).json({
          success: false,
          message: 'Kode Prodi sudah digunakan',
        });
      }
      return res.status(409).json({
        success: false,
        message: 'Nama Prodi sudah ada',
      });
    }
    throw err;
  }
};

exports.update = async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ success: false, message: 'Invalid id' });
  }

  const { error, value } = jurusanSchema.validate(req.body, { abortEarly: true });
  if (error) {
    return res.status(400).json({ success: false, message: error.details[0].message });
  }

  try {
    const updated = await prisma.jurusan.update({
      where: { id },
      data: { 
        kodeProdi: value.kodeProdi.trim(),
        namaProdi: value.namaProdi.trim() 
      },
    });

    return res.json({
      success: true,
      message: 'Jurusan updated',
      data: updated,
    });
  } catch (err) {
    if (isPrismaUniqueError(err)) {
      const field = err.meta?.target?.[0];
      if (field === 'kode_prodi') {
        return res.status(409).json({
          success: false,
          message: 'Kode Prodi sudah digunakan',
        });
      }
      return res.status(409).json({
        success: false,
        message: 'Nama Prodi sudah ada',
      });
    }

    // Prisma throws if not found
    if (err && err.code === 'P2025') {
      return res.status(404).json({ success: false, message: 'Jurusan not found' });
    }

    throw err;
  }
};

exports.remove = async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ success: false, message: 'Invalid id' });
  }

  try {
    // Cek relasi sebelum hapus
    const [kelasCount, bankSoalCount, jadwalCount] = await Promise.all([
      prisma.kelas.count({ where: { jurusanId: id } }),
      prisma.bankSoal.count({ where: { jurusanId: id } }),
      prisma.jadwalUjian.count({ where: { jurusanId: id } }),
    ]);

    const reasons = [];
    if (kelasCount > 0) reasons.push(`${kelasCount} kelas`);
    if (bankSoalCount > 0) reasons.push(`${bankSoalCount} bank soal`);
    if (jadwalCount > 0) reasons.push(`${jadwalCount} jadwal ujian`);

    if (reasons.length > 0) {
      return res.status(409).json({
        success: false,
        message: `Tidak dapat menghapus jurusan. Masih ada ${reasons.join(', ')} yang terhubung dengan jurusan ini. Hapus data terkait terlebih dahulu.`
      });
    }

    await prisma.jurusan.delete({ where: { id } });
    return res.json({ success: true, message: 'Jurusan deleted' });
  } catch (err) {
    if (err && err.code === 'P2025') {
      return res.status(404).json({ success: false, message: 'Jurusan not found' });
    }
    // P2003 = Foreign key constraint failed
    if (err && err.code === 'P2003') {
      return res.status(409).json({
        success: false,
        message: 'Tidak dapat menghapus jurusan. Masih ada data lain yang terhubung. Hapus data terkait terlebih dahulu.'
      });
    }
    throw err;
  }
};


