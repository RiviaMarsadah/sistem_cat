const prisma = require('../config/prisma');

// Utils
function normalizeAnswer(v) {
  return (v || '').toString().trim().toUpperCase();
}

function normalizeMulti(v) {
  const parts = normalizeAnswer(v)
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);
  const uniq = [...new Set(parts)];
  uniq.sort();
  return uniq.join(',');
}

function normalizeCategory(v) {
  // Untuk kategori (B/S), urutan sangat penting dan duplikat (B,B,S) adalah sah.
  // Jadi JANGAN di-sort atau di-uniq.
  return normalizeAnswer(v)
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean)
    .join(',');
}

function getStatusFromAnswer(raw, fallbackStatus) {
  if (fallbackStatus && ['dijawab', 'kosong', 'ragu_ragu'].includes(fallbackStatus)) return fallbackStatus;
  const n = normalizeAnswer(raw);
  if (!n) return 'kosong';
  return 'dijawab';
}

function scoreByType(tipeSoal, kunci, jawaban) {
  const k = normalizeAnswer(kunci);
  const j = normalizeAnswer(jawaban);

  if (!j) return { isBenar: false, skorItem: 0 };

  if (tipeSoal === 'pilgan') {
    return { isBenar: k === j, skorItem: k === j ? 1 : 0 };
  }

  if (tipeSoal === 'pilgan_kompleks') {
    const kk = normalizeMulti(k);
    const jj = normalizeMulti(j);
    return { isBenar: kk === jj, skorItem: kk === jj ? 2 : 0 };
  }

  if (tipeSoal === 'pilgan_kategori') {
    const kk = normalizeCategory(k);
    const jj = normalizeCategory(j);
    return { isBenar: kk === jj, skorItem: kk === jj ? 2 : 0 };
  }

  return { isBenar: false, skorItem: 0 };
}

function seededShuffle(items, seed) {
  const arr = [...items];
  let state = seed >>> 0;
  const rand = () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000; //4.294.967.296
  };

  for (let i = arr.length - 1; i > 0; i--) { //fisher yates shuffle algoritma
    const j = Math.floor(rand() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function mapBankSoalToQuestion(bankSoal, nomorSoal, jawaban) {
  const pick = (v) => (v == null ? '' : String(v).trim());

  const kategori = bankSoal.kategoriSoal;
  const soal = pick(bankSoal.soal);
  const gambar = bankSoal.gambar ? String(bankSoal.gambar).trim() : null;
  const pilihan = [
    pick(bankSoal.kolomA),
    pick(bankSoal.kolomB),
    pick(bankSoal.kolomC),
    pick(bankSoal.kolomD),
    pick(bankSoal.kolomE)
  ].filter(Boolean);

  let type = 'simple';
  let options = pilihan;
  if (kategori === 'pilgan_kompleks') {
    type = 'complex';
  } else if (kategori === 'pilgan_kategori') {
    type = 'category';
  }

  return {
    bankSoalId: bankSoal.id,
    nomorSoal,
    questionText: soal || (type === 'category' ? 'Pilih Benar/Salah untuk pernyataan berikut.' : ''),
    imageUrl: gambar,
    type,
    options,
    // Kita hide correctOption di sisi klien saat sedang berlangsung ujian!
    correctOption: null, 
    jawabanSiswa: jawaban?.jawabanSiswa ?? null,
    statusJawaban: jawaban?.statusJawaban ?? 'kosong',
  };
}


// --- EXPORTS ---

// Untuk nge-cek jadwal dengan token 
exports.getJadwalByToken = async (req, res) => {
  const token = String(req.query.token || '').trim().toUpperCase();
  const siswa = req.user.siswa; // Dari resolveSiswa

  if (!token || token.length !== 6) {
    return res.status(400).json({ success: false, message: 'Token ujian wajib 6 digit kapital.' });
  }

  try {
    const jadwal = await prisma.jadwalUjian.findFirst({
      where: { token },
      include: {
        mataPelajaran: true,
        paketUjian: true,
        kelasJadwal: true
      }
    });

    if (!jadwal) {
      return res.status(404).json({ success: false, message: 'Jadwal ujian tidak ditemukan.' });
    }

    // 1. Cek Kelas
    if (siswa.kelasId) {
      const isEligible = jadwal.kelasJadwal.some(kj => kj.kelasId === siswa.kelasId);
      if (!isEligible) {
         return res.status(403).json({ success: false, message: 'Kelas Anda tidak terdaftar dalam jadwal ujian ini.' });
      }
    }

    // 2. Cek apakah Guru sudah memasukkan Paket
    if (!jadwal.paketUjianId) {
      return res.status(400).json({ success: false, message: 'Soal untuk ujian ini belum disiapkan oleh guru.'});
    }

    // 3. Cek Rentang Waktu
    const now = new Date();
    let isWaiting = false;

    if (now < jadwal.mulai) {
      isWaiting = true;
    }
    
    if (now > jadwal.selesai) {
       return res.status(400).json({ success: false, message: 'Ujian telah berakhir.' });
    }

    return res.json({
       success: true,
       data: {
          id: jadwal.id,
          nama: jadwal.nama,
          durasi: jadwal.durasi,
          mulai: jadwal.mulai,
          selesai: jadwal.selesai,
          opsiKeamanan: jadwal.opsiKeamanan,
          mataPelajaran: jadwal.mataPelajaran.namaMapel,
          paketUjian: jadwal.paketUjian.nama,
          tipeUjian: jadwal.paketUjian.tipeUjian,
          isWaiting
       }
    });

  } catch(error) {
    console.error('getJadwalByToken error:', error);
    return res.status(500).json({ success: false, message: 'Terjadi kesalahan sistem.' });
  }
};

exports.getJadwalHariIni = async (req, res) => {
  const siswaId = req.siswaId;
  
  try {
    const siswa = await prisma.siswa.findUnique({
      where: { id: siswaId },
      select: { kelasId: true }
    });

    if (!siswa || !siswa.kelasId) {
      return res.status(400).json({ success: false, message: 'Data kelas siswa tidak ditemukan.' });
    }
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    const jadwalList = await prisma.jadwalUjian.findMany({
      where: {
        kelasJadwal: {
          some: {
            kelasId: siswa.kelasId
          }
        },
        mulai: { lte: endOfToday },
        selesai: { gte: startOfToday },
        paketUjianId: { not: null }
      },
      include: {
        mataPelajaran: true,
        paketUjian: true
      },
      orderBy: { mulai: 'asc' }
    });

    const result = [];
    for (const j of jadwalList) {
      const existing = await prisma.ujianSiswa.findUnique({
        where: { siswaId_jadwalUjianId: { siswaId, jadwalUjianId: j.id } },
        select: { status: true }
      });

      result.push({
        id: j.id,
        nama: j.nama,
        durasi: j.durasi,
        mulai: j.mulai,
        selesai: j.selesai,
        opsiKeamanan: j.opsiKeamanan,
        mataPelajaran: j.mataPelajaran.namaMapel,
        paketUjian: j.paketUjian.nama,
        tipeUjian: j.paketUjian.tipeUjian,
        statusSiswa: existing ? existing.status : 'belum_mulai'
      });
    }

    return res.json({
      success: true,
      data: result
    });

  } catch (error) {
    console.error('getJadwalHariIni error:', error);
    return res.status(500).json({ success: false, message: 'Terjadi kesalahan sistem.' });
  }
};


exports.mulaiUjian = async (req, res) => {
  const siswaId = req.siswaId;
  const token = String(req.body?.token || '').trim().toUpperCase();
  const jadwalUjianId = req.body?.jadwalUjianId ? Number(req.body.jadwalUjianId) : undefined;

  try {
    const whereClause = { token };
    if (jadwalUjianId) {
      whereClause.id = jadwalUjianId;
    }

    const jadwal = await prisma.jadwalUjian.findFirst({
      where: whereClause,
      include: {
         paketUjian: {
            include: {
               soalPaket: {
                  include: { bankSoal: true }
               }
            }
         }
      }
    });

    if (!jadwal || !jadwal.paketUjianId) {
       return res.status(404).json({ success: false, message: 'Jadwal/Paket ujian tidak valid.' });
    }

    const existing = await prisma.ujianSiswa.findUnique({
      where: { siswaId_jadwalUjianId: { siswaId, jadwalUjianId: jadwal.id } },
      include: {
        jawabanSiswa: { include: { bankSoal: true }, orderBy: { nomorSoal: 'asc' } },
      },
    });

    if (existing && existing.status === 'selesai') {
      return res.status(400).json({
         success: false, message: `Anda sudah mengerjakannya dan telah selesai ujian ini.`
      });
    }

    let ujian = existing;

    if (!ujian) {
      const seed = Math.floor(Math.random() * 1000000000);
      const shuffled = seededShuffle(jadwal.paketUjian.soalPaket, seed);

      const now = new Date();
      const status = now < jadwal.mulai ? 'waiting' : 'berlangsung';

      ujian = await prisma.ujianSiswa.create({
        data: {
          siswaId,
          jadwalUjianId: jadwal.id,
          status: status,
          randomSeed: seed,
          totalSoal: shuffled.length,
          jawabanSiswa: {
            create: shuffled.map((sp, idx) => ({
              bankSoalId: sp.bankSoalId,
              nomorSoal: idx + 1,
              tipeSoal: sp.bankSoal.kategoriSoal,
              statusJawaban: 'kosong',
            })),
          },
        },
        include: {
          jawabanSiswa: { include: { bankSoal: true }, orderBy: { nomorSoal: 'asc' } },
        },
      });
    }

    const soal = ujian.jawabanSiswa.map((j) => mapBankSoalToQuestion(j.bankSoal, j.nomorSoal, j));

    return res.json({
      success: true,
      data: {
        serverTime: new Date(),
        ujianSiswaId: ujian.id,
        status: ujian.status,
        mulaiPada: ujian.mulaiPada, // Ditambahkan untuk timer
        jadwalUjian: {
           id: jadwal.id,
           nama: jadwal.nama,
           durasi: jadwal.durasi,
           selesai: jadwal.selesai,
           opsiKeamanan: jadwal.opsiKeamanan
        },
        soal,
        totalQuestions: soal.length,
      },
    });
  } catch(err) {
    console.error('siswaUjian mulaiUjian error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memulai ujian' });
  }
};


exports.getUjianAktif = async (req, res) => {
  const siswaId = req.siswaId;

  try {
    const ujian = await prisma.ujianSiswa.findFirst({
      where: { 
        siswaId, 
        status: { in: ['berlangsung', 'waiting'] } 
      },
      include: {
        jadwalUjian: { include: { mataPelajaran: true } },
        jawabanSiswa: {
          include: { bankSoal: true },
          orderBy: { nomorSoal: 'asc' },
        },
      },
    });

    if (!ujian) {
      return res.json({ success: true, data: null, message: 'Tidak ada ujian aktif' });
    }

    const soal = ujian.jawabanSiswa.map((j) => mapBankSoalToQuestion(j.bankSoal, j.nomorSoal, j));

    return res.json({
      success: true,
      data: {
        ujianSiswaId: ujian.id,
        status: ujian.status,
        mulaiPada: ujian.mulaiPada, // Ditambahkan untuk timer
        jadwalUjian: {
          id: ujian.jadwalUjian.id,
          nama: ujian.jadwalUjian.nama,
          durasi: ujian.jadwalUjian.durasi,
          selesai: ujian.jadwalUjian.selesai,
          opsiKeamanan: ujian.jadwalUjian.opsiKeamanan,
          mataPelajaran: ujian.jadwalUjian.mataPelajaran,
        },
        soal,
        totalQuestions: soal.length,
      },
    });
  } catch (err) {
    console.error('siswaUjian getUjianAktif error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengecek ujian aktif' });
  }
};

exports.saveProgress = async (req, res) => {
  const siswaId = req.siswaId;
  const ujianSiswaId = Number(req.params.ujianSiswaId);
  const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];

  try {
    const ujian = await prisma.ujianSiswa.findUnique({
      where: { id: ujianSiswaId },
      include: { jawabanSiswa: true },
    });

    if (!ujian || ujian.siswaId !== siswaId || ujian.status !== 'berlangsung') {
      return res.status(404).json({ success: false, message: 'Sesi ujian tidak valid atau sudah selesai' });
    }

    const answerMap = new Map();
    for (const a of answers) {
      const key = Number(a?.bankSoalId);
      answerMap.set(key, { jawabanSiswa: a?.jawabanSiswa ?? '', statusJawaban: a?.statusJawaban });
    }

    const updates = [];
    ujian.jawabanSiswa.forEach((row) => {
      const incoming = answerMap.get(row.bankSoalId);
      if (incoming) {
        const statusJawaban = getStatusFromAnswer(incoming.jawabanSiswa, incoming.statusJawaban);
        updates.push(prisma.jawabanSiswa.update({
          where: { id: row.id },
          data: {
            jawabanSiswa: incoming.jawabanSiswa ? String(incoming.jawabanSiswa) : null,
            statusJawaban,
          },
        }));
      }
    });

    if (updates.length > 0) await prisma.$transaction(updates);

    return res.json({ success: true, message: 'Progress berhasil disimpan' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Gagal menyimpan progress ujian' });
  }
};


exports.submitUjian = async (req, res) => {
  const siswaId = req.siswaId;
  const ujianSiswaId = Number(req.params.ujianSiswaId);
  const tokenCheckOut = String(req.body?.tokenCheckOut || '').trim().toUpperCase();
  const isTimeUp = req.body?.isTimeUp === true;
  const answers = Array.isArray(req.body?.answers) ? req.body.answers : [];

  if (!isTimeUp && (!tokenCheckOut || tokenCheckOut.length !== 6)) {
    return res.status(400).json({ success: false, message: 'Token Checkout wajib 6 karakter.' });
  }

  try {
    const ujian = await prisma.ujianSiswa.findUnique({
      where: { id: ujianSiswaId },
      include: { 
         jawabanSiswa: { include: { bankSoal: true } },
         jadwalUjian: { 
           select: { 
             tokenCheckOut: true,
             mulai: true,
             durasi: true,
             selesai: true
           } 
         }
      },
    });

    if (!ujian || ujian.siswaId !== siswaId || ujian.status === 'selesai') {
      return res.status(404).json({ success: false, message: 'Sesi ujian tidak valid atau sudah disubmit.' });
    }

    // Verifikasi Token atau Timeout
    if (isTimeUp) {
      // Verifikasi di server: apakah benar waktu sudah habis?
      const now = new Date();
      const startTime = new Date(ujian.mulaiPada);
      const examEndTime = new Date(startTime.getTime() + ujian.jadwalUjian.durasi * 60000);
      const scheduleEndTime = new Date(ujian.jadwalUjian.selesai);
      
      const deadline = examEndTime < scheduleEndTime ? examEndTime : scheduleEndTime;
      
      // Beri toleransi 30 detik untuk delay network
      if (now.getTime() < (deadline.getTime() - 30000)) {
        return res.status(400).json({ 
          success: false, 
          message: 'Bypass token ditolak. Waktu ujian di server masih tersedia.' 
        });
      }
    } else {
      if (ujian.jadwalUjian.tokenCheckOut !== tokenCheckOut) {
        return res.status(400).json({ success: false, message: 'Token Checkout salah atau tidak valid.' });
      }
    }

    const answerMap = new Map();
    for (const a of answers) {
       answerMap.set(Number(a?.bankSoalId), { jawabanSiswa: a?.jawabanSiswa ?? '', statusJawaban: a?.statusJawaban });
    }

    let benar = 0, salah = 0, kosong = 0, raguRagu = 0;
    let nilaiBenar = 0, nilaiTotal = 0;

    const updates = ujian.jawabanSiswa.map((row) => {
      const incoming = answerMap.get(row.bankSoalId) || { jawabanSiswa: row.jawabanSiswa || '', statusJawaban: row.statusJawaban };
      const statusJawaban = getStatusFromAnswer(incoming.jawabanSiswa, incoming.statusJawaban);
      const { isBenar, skorItem } = scoreByType(row.tipeSoal, row.bankSoal.jawaban, incoming.jawabanSiswa);

      const weight = (row.tipeSoal === 'pilgan_kompleks' || row.tipeSoal === 'pilgan_kategori') ? 2 : 1;
      nilaiTotal += weight;

      if (statusJawaban === 'kosong') kosong += 1;
      else if (statusJawaban === 'ragu_ragu') raguRagu += 1;

      if (isBenar) {
        nilaiBenar += weight;
        benar += 1;
      } else {
        salah += 1;
      }

      return prisma.jawabanSiswa.update({
        where: { id: row.id },
        data: {
          jawabanSiswa: incoming.jawabanSiswa ? String(incoming.jawabanSiswa) : null,
          statusJawaban, isBenar, skorItem,
        },
      });
    });

    await prisma.$transaction(updates);

    const totalSoal = ujian.jawabanSiswa.length;
    const nilaiAkhir = nilaiTotal > 0 ? Number(((nilaiBenar / nilaiTotal) * 100).toFixed(2)) : 0;

    await prisma.ujianSiswa.update({
      where: { id: ujianSiswaId },
      data: { status: 'selesai', benar, salah, kosong, raguRagu, nilaiAkhir, selesaiPada: new Date() },
    });

    return res.json({
      success: true, message: 'Jawaban berhasil disubmit dan dinilai secara otomatis',
      data: { ujianSiswaId, totalSoal, benar, salah, kosong, raguRagu, nilaiAkhir },
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Gagal mensubmit ujian' });
  }
};


exports.getRiwayatUjian = async (req, res) => {
  const siswaId = req.siswaId;

  try {
    const riwayat = await prisma.ujianSiswa.findMany({
      where: { siswaId, status: 'selesai' },
      include: {
        jadwalUjian: {
          include: { mataPelajaran: true },
        },
      },
      orderBy: { selesaiPada: 'desc' },
    });

    return res.json({
      success: true,
      data: riwayat.map((u) => ({
        ujianSiswaId: u.id,
        namaJadwal: u.jadwalUjian.nama,
        mataPelajaran: u.jadwalUjian.mataPelajaran,
        totalSoal: u.totalSoal,
        benar: u.benar,
        salah: u.salah,
        kosong: u.kosong,
        nilaiAkhir: Number(u.nilaiAkhir),
        mulaiPada: u.mulaiPada,
        selesaiPada: u.selesaiPada,
      })),
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Gagal memuat riwayat ujian' });
  }
};

exports.getHasilUjian = async (req, res) => {
  const siswaId = req.siswaId;
  const ujianSiswaId = Number(req.params.ujianSiswaId);

  try {
    const ujian = await prisma.ujianSiswa.findUnique({
      where: { id: ujianSiswaId },
      include: {
        jadwalUjian: { include: { mataPelajaran: true } },
        jawabanSiswa: {
          include: { bankSoal: true }, orderBy: { nomorSoal: 'asc' },
        },
      },
    });

    if (!ujian || ujian.siswaId !== siswaId) {
      return res.status(404).json({ success: false, message: 'Hasil ujian tidak ditemukan' });
    }

    const pick = (v) => (v == null ? '' : String(v).trim());

    return res.json({
      success: true,
      data: {
        ujianSiswaId: ujian.id,
        status: ujian.status,
        rekap: {
          totalSoal: ujian.totalSoal, benar: ujian.benar, salah: ujian.salah, kosong: ujian.kosong,
          raguRagu: ujian.raguRagu, nilaiAkhir: Number(ujian.nilaiAkhir), mulaiPada: ujian.mulaiPada, selesaiPada: ujian.selesaiPada,
        },
        jadwalUjian: {
          id: ujian.jadwalUjian.id, nama: ujian.jadwalUjian.nama, mataPelajaran: ujian.jadwalUjian.mataPelajaran,
        },
        // Di hasil ujian, correctOption dipertontonkan
        detail: ujian.jawabanSiswa.map((j) => {
          const b = j.bankSoal;
          const k = b.kategoriSoal;
          const opts = k === 'pilgan_kompleks' ? [b.kolomA, b.kolomB, b.kolomC, b.kolomD, b.kolomE, b.kolomF] : 
                       k === 'pilgan_kategori' ? [b.kolomA, b.kolomB, b.kolomC] : 
                       [b.kolomA, b.kolomB, b.kolomC, b.kolomD, b.kolomE];
          return {
            nomorSoal: j.nomorSoal, tipeSoal: j.tipeSoal, soal: b.soal, gambar: b.gambar, options: opts.filter(Boolean),
            jawabanSiswa: j.jawabanSiswa, statusJawaban: j.statusJawaban, isBenar: j.isBenar, correctOption: b.jawaban
          };
        }),
      },
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Gagal memuat hasil ujian' });
  }
};

exports.cancelWaitingUjian = async (req, res) => {
  const siswaId = req.siswaId;
  const ujianSiswaId = Number(req.params.ujianSiswaId);

  try {
    const ujian = await prisma.ujianSiswa.findUnique({
      where: { id: ujianSiswaId }
    });

    if (!ujian || ujian.siswaId !== siswaId) {
      return res.status(404).json({ success: false, message: 'Data ujian tidak ditemukan.' });
    }

    if (ujian.status !== 'waiting') {
      return res.status(400).json({ success: false, message: 'Hanya ujian berstatus waiting yang bisa dibatalkan.' });
    }

    // Hapus jawabanSiswa dulu (cascading manual jika tidak di set di prisma)
    await prisma.jawabanSiswa.deleteMany({
      where: { ujianSiswaId: ujianSiswaId }
    });

    await prisma.ujianSiswa.delete({
      where: { id: ujianSiswaId }
    });

    return res.json({ success: true, message: 'Antrian ujian berhasil dibatalkan.' });
  } catch (err) {
    console.error('cancelWaitingUjian error:', err);
    return res.status(500).json({ success: false, message: 'Gagal membatalkan antrian ujian.' });
  }
};

exports.getUjianStatus = async (req, res) => {
  const siswaId = req.siswaId;
  const ujianSiswaId = Number(req.params.ujianSiswaId);

  try {
    const ujian = await prisma.ujianSiswa.findUnique({
      where: { id: ujianSiswaId },
      select: {
        id: true,
        siswaId: true,
        status: true
      }
    });

    if (!ujian || ujian.siswaId !== siswaId) {
      return res.status(404).json({ success: false, message: 'Data ujian tidak ditemukan.' });
    }

    return res.json({
      success: true,
      data: {
        status: ujian.status
      }
    });
  } catch (err) {
    console.error('getUjianStatus error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengecek status ujian.' });
  }
};

